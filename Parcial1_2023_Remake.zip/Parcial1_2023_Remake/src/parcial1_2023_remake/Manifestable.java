
package parcial1_2023_remake;

/**
 *
 * @author karol
 */
public interface Manifestable {
    public abstract void darManifiesto();
}
