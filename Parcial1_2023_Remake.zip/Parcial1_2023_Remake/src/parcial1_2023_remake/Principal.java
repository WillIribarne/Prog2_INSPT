
package parcial1_2023_remake;

/**
 *
 * @author karol
 */
public class Principal {

    public static void main(String[] args) {
        
        PuntoAtraque p1 = new PuntoAtraque();
        PuntoAtraque p2 = new PuntoAtraque();
        PuntoAtraque p3 = new PuntoAtraque();
        PuntoAtraque p4 = new PuntoAtraque();
        PuntoAtraque p5 = new PuntoAtraque();
        
        AtlantisISS estacion = new AtlantisISS();
        
        estacion.agregarPuntoAtraque(p1); estacion.agregarPuntoAtraque(p2); estacion.agregarPuntoAtraque(p3); estacion.agregarPuntoAtraque(p4); estacion.agregarPuntoAtraque(p5); 
        
        NaveCargo ncar1= new NaveCargo("Baterías recargables", 120, "Neptuno", 21);
        NaveCruiser ncru1 = new NaveCruiser(0, "Mercurio", 8);
        NaveCargo ncar2= new NaveCargo("Sustancias cósmicas", 90, "Marte", 15);
        NaveCruiser ncru2 = new NaveCruiser(12, "Urano", 48);
        
        estacion.estacionarNave(ncar1);
        estacion.estacionarNave(ncru1);
        estacion.estacionarNave(ncar2);
        estacion.estacionarNave(ncru2);
        
        System.out.println("**********");
        estacion.mostrarManifiestos();
        
        
        
//        System.out.println(p1.getNaveEstacionada());
//        System.out.println(p2.getNaveEstacionada());
//        System.out.println(p3.getNaveEstacionada());
//        System.out.println(p4.getNaveEstacionada());
//        System.out.println(p5.getNaveEstacionada());
    }
    
}
