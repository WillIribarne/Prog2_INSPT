
package parcial1_2023_remake;

/**
 *
 * @author karol
 */
public abstract class Nave implements Manifestable {
    private String planetaOrigen;
    private int cantTripulantes;

    public Nave(String planetaOrigen, int cantTripulantes) {
        this.planetaOrigen = planetaOrigen;
        this.cantTripulantes = cantTripulantes;
    }

    public int getCantTripulantes() {
        return cantTripulantes;
    }
        
    public abstract boolean puedeEstacionar();
        
}
