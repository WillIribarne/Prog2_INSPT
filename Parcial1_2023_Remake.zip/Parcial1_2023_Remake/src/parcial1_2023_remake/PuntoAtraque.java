
package parcial1_2023_remake;

/**
 *
 * @author karol
 */
public class PuntoAtraque {

    private Nave naveEstacionada;
    private boolean estaLibre; //false por defecto

    public PuntoAtraque() {
        this.estaLibre = true;
    }
    
    public void setEstaLibre(boolean libre){
        this.estaLibre = libre;
    }
        
    public boolean isEstaLibre(){
        return this.estaLibre;
    }
   
    
    public void setEstacionarNave(Nave nave){ 
        if(this.isEstaLibre() && nave.puedeEstacionar()){
            this.naveEstacionada = nave;
            setEstaLibre(false);            
        } 
    }
    
           
    public Nave getNaveEstacionada(){
        return this.naveEstacionada;
    }
    

    @Override
    public String toString() {
        return "PuntoAtraque{ " + "naveEstacionada=" + naveEstacionada + ", estaLibre=" + estaLibre + '}';
    }
    
    
    
    
    
    
    
    
}
