
package parcial1_2023_remake;

/**
 *
 * @author karol
 */
public class NaveCargo extends Nave {
    private static final double CARGA_MAX = 100;
    private String descripcionCarga;
    private double volumenCarga;

    
    public NaveCargo(String descripcionCarga, double volumenCarga, String planetaOrigen, int cantTripulantes) {
        super(planetaOrigen, cantTripulantes);
        this.descripcionCarga = descripcionCarga;
        this.volumenCarga = volumenCarga;
    }

        
    @Override
    public void darManifiesto() {
        System.out.println( this.descripcionCarga  + " (" + this.volumenCarga + " m3)");
    }
    
        
    @Override
    public boolean puedeEstacionar(){
        return this.volumenCarga <= CARGA_MAX;
    }
        
    @Override
    public String toString() {
        return "NaveCargo{ " + "Carga: " + descripcionCarga + ", Volumen: " + volumenCarga + '}';
    }
               
    
}
