
package parcial1_2023_remake;

/**
 *
 * @author karol
 */
public class NaveCruiser extends Nave{
    private static final int CANT_MIN_PASAJEROS = 1;
    private int cantPasajeros;

    
    public NaveCruiser(int cantPasajeros, String planetaOrigen, int cantTripulantes) {
        super(planetaOrigen, cantTripulantes);
        this.cantPasajeros = cantPasajeros;
    }

    
    private int totalPasajeros(){
        return this.cantPasajeros + getCantTripulantes();
    }
    
       
    @Override
    public void darManifiesto() {
        System.out.println("Porcentaje de pasajeros: " + this.cantPasajeros * 100 / totalPasajeros()  + " %");        
    }
    
    
    @Override
    public boolean puedeEstacionar(){
        return this.cantPasajeros >= CANT_MIN_PASAJEROS;
    }

    
    @Override
    public String toString() {
        return "NaveCruiser{ " + "Cantidad de Pasajeros: " + cantPasajeros + '}';
    }
    
    
                
}


    