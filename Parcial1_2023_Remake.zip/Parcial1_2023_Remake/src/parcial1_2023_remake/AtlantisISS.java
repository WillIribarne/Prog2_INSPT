
package parcial1_2023_remake;

import java.util.ArrayList;

/**
 *
 * @author karol
 */
public class AtlantisISS {
    private ArrayList<PuntoAtraque> puntosAtraque;

    public AtlantisISS() {
        this.puntosAtraque = new ArrayList<>();
    }
    
    
    public void agregarPuntoAtraque(PuntoAtraque punto){
        if(punto!=null && !puntosAtraque.contains(punto)){
            puntosAtraque.add(punto);
        }
    }
    
        
    public void mostrarManifiestos(){
        for(PuntoAtraque punto: puntosAtraque){
            if(!punto.isEstaLibre()){
                punto.getNaveEstacionada().darManifiesto();
            }
        }
    }
    
    
    public void estacionarNave(Nave nave){
        int i =0;        
        while(i<puntosAtraque.size() && !puntosAtraque.get(i).isEstaLibre()){
            i++;
        }
        if(i==puntosAtraque.size()){
            System.out.println("Todos los atraques se encuentran ocupados");            
        } else{
            puntosAtraque.get(i).setEstacionarNave(nave); //creo que esta línea es LA LÍNEA CRUCIAL para el inciso 2) del ejercicio >> No va con get(i+1), sino con get(i)
        }        
    }
    
    
    //método de prueba para ver cómo sale la lista de puntos de atraques (con sus naves estacionadas o libres):
//    public void mostrarEstadoAtraques(){
//        for(PuntoAtraque punto: puntosAtraque){
//            System.out.println(punto);
//        }
//    }    
}
